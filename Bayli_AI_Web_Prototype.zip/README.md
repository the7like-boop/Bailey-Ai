# Bayli AI — erster Web-Prototyp

Eine responsive, deutschsprachige Startoberfläche mit Weltraum-Optik und B-Logo.

## Ausprobieren
Öffne `index.html` direkt im Browser. Es ist keine Installation erforderlich. Klicke auf **Als Gast fortfahren**, um den Arbeitsraum zu öffnen.

## Enthalten
- Startbildschirm und Gastmodus
- Bereiche für Chatnotizen, Projekte, Codeentwürfe, Recherche und Wissensnotizen
- Einfacher Cosmos-Überblick über die acht Planeten
- Verlauf, Dateien und Einstellungen als vorbereitete Bereiche
- Responsive Darstellung für Smartphone und Desktop

## Ehrlicher Funktionsstatus
Dies ist ein Frontend-Prototyp. Es gibt noch keine echte KI-Anbindung, Anmeldung, Datenbank oder dauerhafte Speicherung. Notizen sind nur vorläufig und gehen beim Neuladen verloren. Der Codebereich führt keinen Code aus.

## In GitHub veröffentlichen
Lege `index.html` und `README.md` im Hauptverzeichnis des Repositorys ab. Um die Website online zu stellen, öffne in GitHub **Settings → Pages** und wähle den Branch `main` sowie den Ordner `/ (root)`, sofern GitHub Pages für das Repository verfügbar ist.
